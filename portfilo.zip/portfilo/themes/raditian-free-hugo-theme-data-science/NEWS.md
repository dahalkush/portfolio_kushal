# raditian_free_hugo_theme_data_science 0.0.1.9000 (Development Version)

* Added cv folder with resume
* Safe HTML improvements

# raditian_free_hugo_theme_data_science 0.0.1

* Initial version of the "raditian" data science theme
* Added a `NEWS.md` file to track changes to the package.
