# MODIFIED VERSION OF RADITIAN HUGO THEME

- __Designed for Data Scientists__ that wish to create and showcase project portfolios
- __Integrates with Blogdown__, an R package for generating websites

![Example Portfolio](images/example_portfolio.gif)
