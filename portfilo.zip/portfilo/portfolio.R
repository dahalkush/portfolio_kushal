library(portfoliodown) 

portfoliodown::new_portfolio_site()

# Serve the site locally (at localhost:1234)
portfoliodown::serve_site(port = 1234)